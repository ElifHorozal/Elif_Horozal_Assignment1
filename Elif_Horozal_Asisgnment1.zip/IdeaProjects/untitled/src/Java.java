import javax.swing.JOptionPane;
    public class Java {
         public static void main(String[] args) {
             JOptionPane.showMessageDialog(null, "The first player who reaches 5 points wins.", "Let's start!",JOptionPane.INFORMATION_MESSAGE );

             int round = 1;
             int myScore = 0;
             int yourScore = 0;

             while (myScore < 5 && yourScore < 5) {

                 String yourMove;
                 yourMove = JOptionPane.showInputDialog(null, "Your score= " +    yourScore + "   My score= " + myScore + "" + "\nRock, scissor or paper?" , "Round: " + round ,JOptionPane.INFORMATION_MESSAGE);



                 if ("rock" != yourMove.intern() && "paper" != yourMove.intern() && "scissor" != yourMove.intern() && "Rock" != yourMove.intern() && "Paper" != yourMove.intern() && "Scissor" != yourMove.intern() && "ROCK" != yourMove.intern() && "PAPER" != yourMove.intern() && "SCISSOR" != yourMove.intern())
                     JOptionPane.showMessageDialog(null, "Please enter something proper.", "Warning!",JOptionPane.INFORMATION_MESSAGE );

                 else {

                     int number = (int) (Math.random() * 3);
                     //0= rock, 1= paper, 2= scissor.

                     if (("rock"==yourMove.intern() && number==0) || ("paper"==yourMove.intern() && number==1) || ("scissor"==yourMove.intern() && number==2))
                         JOptionPane.showMessageDialog(null, "It's a tie.", "Message",JOptionPane.INFORMATION_MESSAGE );

                     else if ((("scissor" == yourMove.intern()) && number == 1) || (("Scissor" == yourMove.intern()) && number == 1) || (("SCISSOR" == yourMove.intern()) && number == 1)) {
                         JOptionPane.showMessageDialog(null, "My answer was paper. Scissor cuts paper. You win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++yourScore;
                     }
                     else if ((("paper" == yourMove.intern()) && number == 0) || (("Paper" == yourMove.intern()) && number == 0) || (("PAPER" == yourMove.intern()) && number == 0)) {
                         JOptionPane.showMessageDialog(null, "My answer was rock. Paper eats rock. You win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++yourScore;
                     }
                     else if ((("rock" == yourMove.intern()) && number == 2) || (("Rock" == yourMove.intern()) && number == 2) || (("ROCK" == yourMove) && number == 2)) {
                         JOptionPane.showMessageDialog(null, "My answer was scissor. Rock breaks scissor. You win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++yourScore;
                     }
                     else if ((("scissor" == yourMove.intern()) && number == 0) || (("Scissor" == yourMove.intern()) && number == 0) || (("SCISSOR" == yourMove.intern()) && number == 0)) {
                         JOptionPane.showMessageDialog(null, "My answer was rock. Rock breaks scissor. I win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++myScore;
                     }
                     else if ((("paper" == yourMove.intern()) && number == 2) || (("Paper" == yourMove.intern()) && number == 2) || (("PAPER" == yourMove.intern()) && number == 2)) {
                         JOptionPane.showMessageDialog(null, "My answer was scissor. Scissor cuts paper. I win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++myScore;
                     }
                     else {
                         JOptionPane.showMessageDialog(null, "My answer was paper. Paper eats rock. I win!", "Message",JOptionPane.INFORMATION_MESSAGE );
                         ++myScore;
                     }
                 }
                 ++round;
             }
             if (yourScore == 5)
                 JOptionPane.showMessageDialog(null, "Congrats! You win!", "Message",JOptionPane.INFORMATION_MESSAGE );

             else
                 JOptionPane.showMessageDialog(null, "Congrats! I win!", "Message",JOptionPane.INFORMATION_MESSAGE );

         }
    }

