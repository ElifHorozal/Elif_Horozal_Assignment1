import javax.swing.JOptionPane;
     public class Assignment {
         public static void main(String[] args) {

             JOptionPane.showMessageDialog(null, "The first player who reaches 5 points wins.", "Let's start!", JOptionPane.INFORMATION_MESSAGE);

             int round = 1;
             int myScore = 0;
             int yourScore = 0;

             while (myScore < 5 && yourScore < 5) {

                 String yourMove;
                 yourMove = JOptionPane.showInputDialog(null, "Your score= " + yourScore + "   My score= " + myScore + "" + "\nRock, scissor or paper?", "Round: " + round, JOptionPane.INFORMATION_MESSAGE);


                 if (!yourMove.equals("rock") && !yourMove.equals("Rock") && !yourMove.equals("ROCK") && !yourMove.equals("scissor") && !yourMove.equals("Scissor") && !yourMove.equals("SCISSOR") && !yourMove.equals("paper") && !yourMove.equals("Paper") && !yourMove.equals("PAPER"))
                     JOptionPane.showMessageDialog(null, "It is invalid.", "Warning!", JOptionPane.INFORMATION_MESSAGE);

                 else {

                     int number = (int) (Math.random() * 3);
                     //0= rock, 1= paper, 2= scissor.


                     if (yourMove.equals("rock") || yourMove.equals("Rock") || yourMove.equals("ROCK")) {
                         if (number == 0)
                             JOptionPane.showMessageDialog(null, "It's a tie.", "Message", JOptionPane.INFORMATION_MESSAGE);

                         else if (number == 1) {
                             JOptionPane.showMessageDialog(null, "My answer was paper. Paper eats rock. I win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++myScore;
                         }
                         else {
                             JOptionPane.showMessageDialog(null, "My answer was scissor. Rock breaks scissor. You win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++yourScore;
                         }
                     }
                     else if (yourMove.equals("scissor") || yourMove.equals("Scissor") || yourMove.equals("SCISSOR")) {
                         if (number == 0) {
                             JOptionPane.showMessageDialog(null, "My answer was rock. Rock breaks scissor. I win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++myScore;
                         }
                         else if (number == 1) {
                             JOptionPane.showMessageDialog(null, "My answer was paper. Scissor cuts paper. You win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++yourScore;
                         }
                         else
                             JOptionPane.showMessageDialog(null, "It's a tie.", "Message", JOptionPane.INFORMATION_MESSAGE);
                     }
                     else {
                         if (number == 0) {
                             JOptionPane.showMessageDialog(null, "My answer was rock. Paper eats rock. You win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++yourScore;
                         }
                         else if (number == 1)
                             JOptionPane.showMessageDialog(null, "It's a tie.", "Message", JOptionPane.INFORMATION_MESSAGE);

                         else{
                             JOptionPane.showMessageDialog(null, "My answer was scissor. Scissor cuts paper. I win!", "Message", JOptionPane.INFORMATION_MESSAGE);
                             ++myScore;
                         }
                     }
                     ++round;
                 }
             }
             if (yourScore == 5)
                 JOptionPane.showMessageDialog(null, "Congrats! You win!", "Message", JOptionPane.INFORMATION_MESSAGE);

             else
                 JOptionPane.showMessageDialog(null, "Congrats! I win!", "Message", JOptionPane.INFORMATION_MESSAGE);
         }
     }


