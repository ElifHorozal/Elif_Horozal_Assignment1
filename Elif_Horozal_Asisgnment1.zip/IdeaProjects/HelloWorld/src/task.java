import java.util.Scanner;

public class task {
    public static void main(String[] args){
       double midtermScore, quizScore, finalExamScore, avgScore;
        Scanner scn = new Scanner(System.in);

       // Get Scores from Users
        System.out.print("Please enter the midterm score: ");
        midtermScore = scn.nextDouble();

        System.out.print("Please enter the quiz score.: ");
        quizScore = scn.nextDouble();

        System.out.print("Please enter the final exam score: ");
        finalExamScore = scn.nextDouble();

        avgScore = (midtermScore * 0.30 ) + (quizScore * 0.10) + (finalExamScore * 0.60 );

        System.out.println("Your score is " + avgScore);

        if (avgScore >= 90)
            System.out.println("Grade: A ");
        else if(avgScore < 90 && avgScore >= 80 )
            System.out.println("Grade: B ");
        else if(avgScore < 80 && avgScore >= 70 )
            System.out.println("Grade: C ");
        else if(avgScore <70 && avgScore >= 60 )
            System.out.println("Grade: D ");
        else if(avgScore < 60 && avgScore >= 50)
            System.out.println("Grade: E ");
        else
            System.out.println("Grade: F ");







    }
}
