public class ChineseZodiac {
    public static void main(String[] args) {

        System.out.print("Enter a year");
    }
}
