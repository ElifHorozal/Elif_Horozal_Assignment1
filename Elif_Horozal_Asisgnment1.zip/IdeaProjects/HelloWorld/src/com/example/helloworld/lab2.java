package com.example.helloworld;

public class lab2 {
}
